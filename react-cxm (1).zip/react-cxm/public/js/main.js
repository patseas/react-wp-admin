var activity = document.getElementById("activity");
var activityBtn = document.getElementById("activityBtn");
var body = document.body;
activityBtn.onclick = function () {
  activity.classList.toggle("active");
  activityBtn.classList.toggle("active");
  body.classList.toggle("active");
};
window.onclick = function (event) {
  if (event.target == activity) {
    activity.classList.remove("active");
    activityBtn.classList.remove("active");
    body.classList.remove("active");
  }
};

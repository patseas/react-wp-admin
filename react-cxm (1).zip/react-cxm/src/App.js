import React from "react";
import Menu from "./Base/Menu";
import Home from "./Home.jsx/Home";

export default function App() {
  return (
    <div className="wrapper">
      <Menu />
      <Home />
    </div>
  );
}

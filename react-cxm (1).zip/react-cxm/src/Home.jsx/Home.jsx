import React, { useState } from "react";
import Activity from "./Activity/Activity";
import Card from "./Card/Card";

export default function Home() {
  const [activity, setActivity] = useState(false);

  return (
    <>
      <div className="home">
        <div className="home__inner">
          <div className="home__content">
            <h2>
              Dashboard
              <div
                className="activityBtn"
                id="activityBtn"
                onClick={() => setActivity(true)}
              >
                Activity
              </div>
            </h2>
            <h1>
              Welcome back, <span>Joe</span>! Let’s get a few things out of the
              way.
            </h1>
            <div className="home__content-state">
              State <span></span>Needs attention
            </div>
            <p>
              This is what's happening today. Generally, you are on track, but
              we need your attention for 5 minutes to take care of a couple of
              pending items.
            </p>
            <a href="#" className="button primary">
              Start here
              <img src="images/icons/arrow-right.svg" alt="" />
            </a>
          </div>
          <div className="home__content">
            <p className="sm">Overview</p>
            <h3>Last week’s report is ready. See how you did.</h3>
            <a href="#" className="button download">
              Download <img src="images/icons/download.svg" alt="" />
            </a>
            <Card />
          </div>
          <div className="home__content">
            <p className="sm">Tasks</p>
            <h3>Here’s what you need to do today.</h3>
            <div className="checkbox">
              <input type="checkbox" />
              <label forhtml="">Brian Lavery’s emails are bouncing.</label>
              <a href="#">
                Update Harry’s address
                <img src="images/icons/chevron-right.svg" alt="" />
              </a>
            </div>
            <div className="checked">
              <img src="images/icons/checked.svg" alt="" />
              Get back to Marry Trevor. She messaged you from your website.
            </div>
            <div className="checkbox">
              <input type="checkbox" />
              <label forhtml="">
                Laura Smith hasn’t been responding to your messages. Don’t lose
                her.
              </label>
              <a href="#">
                Call Laura
                <img src="images/icons/chevron-right.svg" alt="" />
              </a>
            </div>
          </div>
        </div>
      </div>
      <Activity activity={activity} setActivity={setActivity} />
    </>
  );
}

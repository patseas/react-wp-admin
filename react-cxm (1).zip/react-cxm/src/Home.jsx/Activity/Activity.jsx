import React, { useEffect, useState } from "react";
import ActivityItem from "./ActivityItem";
import { ActivityModul } from "./ActivityModul";

export default function Activity({ activity, setActivity }) {
  useEffect(() => {
    if (activity) {
      document.body.classList.add("active");
    }
  }, [activity]);
  const setActivState = (e) => {
    if (e.target === e.currentTarget) {
      setActivity(false);
      document.body.classList.remove("active");
    }
  };
  return (
    <div
      className={"activity " + (activity ? "active" : "")}
      id="activity"
      onClick={setActivState}
    >
      <div className="activity__inner">
        <h2>Activity</h2>
        <ul>
          {ActivityModul.map((ActivityItems) => {
            return (
              <ActivityItem
                key={ActivityItems.id}
                link={ActivityItems.link}
                title={ActivityItems.title}
                text={ActivityItems.text}
                status={ActivityItems.status}
              />
            );
          })}
        </ul>
      </div>
    </div>
  );
}

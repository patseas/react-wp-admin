import React from "react";

export default function ActivityItem(props) {
  return (
    <li className={props.status}>
      <h6 className="sm">{props.date}</h6>
      <p>{props.title}</p>
      {props.text.map((text, index) => (
        <p className="sm" key={index}>
          {text}
        </p>
      ))}
      <a href={props.link}>View</a>
    </li>
  );
}

export const ActivityModul = [
  {
    id: "activity-1",
    date: "Yesterday",
    title: "New client",
    text: ["Jane Cooper was added to your customer list."],
    link: "https://www.fiverr.com/madilyani/",
    status: "active",
  },
  {
    id: "activity-2",
    date: "Yesterday",
    title: "Reminder",
    text: ["Subject: Tax Day Approaching"],
    link: "https://www.fiverr.com/madilyani/",
    status: "",
  },
  {
    id: "activity-3",
    date: "One month ago",
    title: "Follow up",
    text: [
      "You reached out to Wade Warren and you are no longer at risk of losing him.",
      "Subject: Portfolio Management",
    ],
    link: "https://www.fiverr.com/madilyani/",
    status: "",
  },
  {
    id: "activity-4",
    date: "One month ago",
    title: "Campaign",
    text: [
      "Your campaign “Back to School” was completed successfully.",
      "Total audience reached: 3,000",
    ],
    link: "https://www.fiverr.com/madilyani/",
    status: "",
  },
  {
    id: "activity-5",
    date: "One month ago",
    title: "New website",
    text: [
      "You created your first website and you are ready for new adventures.",
      "http://www.zencorporation.com",
    ],
    link: "https://www.fiverr.com/madilyani/",
    status: "",
  },
  {
    id: "activity-6",
    date: "Two months ago",
    title: "New client",
    text: ["Robert Fox was added to your customer list."],
    link: "https://www.fiverr.com/madilyani/",
    status: "",
  },
];

export const CardModul = [
  {
    id: "card-1",
    number: "24",
    numberExtra: "4",
    value: "80",
    title: "Total clients",
    link: "https://www.fiverr.com/madilyani/",
  },
  {
    id: "card-2",
    number: "3",
    numberExtra: "2",
    value: "50",
    title: "New clients found online",
    link: "https://www.fiverr.com/madilyani/",
  },
  {
    id: "card-3",
    number: "88%",
    numberExtra: "22%",
    value: "40",
    title: "Read your email",
    link: "https://www.fiverr.com/madilyani/",
  },
];

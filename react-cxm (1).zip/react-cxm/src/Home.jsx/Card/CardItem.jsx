import React from "react";
import CardProgress from "./CardProgress";

export default function CardItem(props) {
 

  return (
    <div className="homeCard">
      <div className="homeCard__header">
        <div className="homeCard__header-number">
          {props.number}
          <span>
            <img src="images/icons/arrow-top.svg" alt="" /> {props.numberExtra}
          </span>
        </div>
        <CardProgress value={props.value} />
      </div>
      <div className="homeCard__body">
        <p>{props.title}</p>
        <a href={props.link}>
          View <img src="images/icons/chevron-right.svg" alt="" />
        </a>
      </div>
    </div>
  );
}

import React, { useEffect, useRef } from "react";

export default function CardProgress({ value }) {
  const circleRef = useRef();
  useEffect(() => {
    if (circleRef.current) {
      var circle = circleRef.current;
      var radius = circle.r.baseVal.value;
      var circumference = radius * 2 * Math.PI;

      circle.style.strokeDasharray = `${circumference} ${circumference}`;
      circle.style.strokeDashoffset = `${circumference}`;

      function setProgress(percent) {
        const offset = circumference - (percent / 100) * circumference;
        circle.style.strokeDashoffset = offset;
      }

      const input = document.querySelector("input");
      setProgress(input.value);
    }
  }, [circleRef]);

  return (
    <div className="homeCard__header-progress">
      <input
        defaultValue={value ?? 0}
        type="number"
        step="5"
        min="0"
        max="100"
        placeholder="0"
      />
      <svg className="progress-ring" width="34" height="34">
        <circle
          ref={circleRef}
          className="progress-ring__circle"
          stroke=""
          strokeWidth="3"
          fill="transparent"
          r="15"
          cx="17"
          cy="17"
        />
      </svg>
    </div>
  );
}

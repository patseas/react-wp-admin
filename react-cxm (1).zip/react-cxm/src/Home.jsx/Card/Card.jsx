import React from "react";
import CardItem from "./CardItem";
import { CardModul } from "./CardModul";

export default function Card() {
  return (
    <div className="home__content-row">
      {CardModul.map((CardItems) => {
        return (
          <CardItem
            key={CardItems.id}
            link={CardItems.link}
            title={CardItems.title}
            number={CardItems.number}
            numberExtra={CardItems.numberExtra}
            value={CardItems.value}
          />
        );
      })}
    </div>
  );
}
